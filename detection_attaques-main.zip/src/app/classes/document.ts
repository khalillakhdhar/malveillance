export class Document {
    id:string;
date_heure:string;
url:string;
detection:string;
description:string;
classe:string;
}
