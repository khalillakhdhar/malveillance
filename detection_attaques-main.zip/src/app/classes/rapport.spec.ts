import { Rapport } from './rapport';

describe('Rapport', () => {
  it('should create an instance', () => {
    expect(new Rapport()).toBeTruthy();
  });
});
