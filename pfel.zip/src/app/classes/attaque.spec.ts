import { Attaque } from './attaque';

describe('Attaque', () => {
  it('should create an instance', () => {
    expect(new Attaque()).toBeTruthy();
  });
});
