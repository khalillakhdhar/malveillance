export class Rapport {
    id:string;
    titre:string;
    type:string;
    date_heure:string;
    ip:string;
}
