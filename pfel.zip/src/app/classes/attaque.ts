export class Attaque {
    id:string;
    classification:string;
    date_heures:string;
    recommandation="quarantaine";
}
