export class User {
    id:string;
    nom:string;
    login:string;
    mdp:string;
    tel:string;
    adresse:string;
    grade:string;
    ipref:string[];
}
