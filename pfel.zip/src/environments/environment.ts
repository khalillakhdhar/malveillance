// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  firebase:
  {   apiKey: "AIzaSyCCBNeO6JdTDNBYVLYy9W5Odm5a9tjAfuc",
  authDomain: "detection-403ec.firebaseapp.com",
  projectId: "detection-403ec",
  storageBucket: "detection-403ec.appspot.com",
  messagingSenderId: "158082865388",
  appId: "1:158082865388:web:8c5e29fd389bb84e7aedc9",
  measurementId: "G-BNSN8B2D2Y"}
};
